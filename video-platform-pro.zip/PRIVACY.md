# Privacy Policy / গোপনীয়তা নীতি (Short)

**English:** We collect basic account info (email, displayName) via Firebase Auth and store your video records, likes, comments, and watch history. Ads HTML is injected from admin-only Firestore doc. We don't sell personal data.  
**Bangla:** আমরা Firebase Auth দিয়ে ইমেইল/নাম নেই এবং আপনার ভিডিও, লাইক, কমেন্ট, ও ওয়াচ হিস্ট্রি সংরক্ষণ করি। `admin/ads` থেকে কেবল অ্যাড HTML ইনজেক্ট করা হয় যা কেবল অ্যাডমিন লিখতে পারে। আমরা ব্যক্তিগত তথ্য বিক্রি করি না।
