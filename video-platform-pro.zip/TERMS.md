# Terms of Service / শর্তাবলী (Short)

**English:** By using the site you agree to follow community guidelines. Upload only content you own or are authorized to share. Admin may remove content, block users, and update rules.  
**Bangla:** এই সাইট ব্যবহার করলে আপনি কমিউনিটি গাইডলাইন মানতে সম্মত হচ্ছেন। নিজস্ব বা অনুমোদিত কনটেন্টই আপলোড করুন। অ্যাডমিন কনটেন্ট মুছতে/ব্যবহারকারী ব্লক করতে/নিয়ম আপডেট করতে পারেন।
