# NovaTube — Video Sharing (Firebase + Admin + Ads)

A production-ready starter for a link-first video site with optional Storage uploads, custom player, admin panel, ads injection, Firebase Auth v9 (redirect), Firestore, and CI deploy.

## Features
- Home/Trending/New/Hot/Uploaded/History/Profile navigation (hash router)
- Share **links** (YouTube, Vimeo, MP4) and **optional file uploads**
- Custom player: click-to-play, overlay controls, mute/unmute, fullscreen, playsinline
- Short vs Long handling via `isShort`
- Likes, views, share copy, watch-position saved to `users/{uid}.watchHistory`
- Admin panel (role-based): create/edit/delete videos, set ads (HTML + VAST tag), enable/disable uploads, manage banned words, view reports
- Real-time ad injection from `admin/ads` into **top** and **sidebar** slots
- Simulated 3s video-ad overlay hook + comments to integrate **Google IMA**
- Security rules included (Firestore + Storage)
- Minimal Node helper server (`/api/og`, `/api/sign`), ready for Cloud Run or Functions
- CI via GitHub Actions + deploy script
- Policies: PRIVACY, TERMS, DISCLAIMER (Bangla + English)

## Quick Start

```bash
npm install
# Optional: run helper server locally
npm run dev
# Static preview
npx serve public
```

### Firebase setup
1. Create project (already have: `videos-37e8f`).  
2. In **Authentication → Sign-in method** enable **Google** and **Email/Password**. Add your domain to **Authorized domains**.
3. In **Firestore** create the following docs (sample provided in `/samples`):
   - `users/{yourUid}` with `role: "admin"`
   - `admin/config` with `storageUploadsEnabled: true|false`
   - `admin/ads` for ad HTML and VAST tag
4. Replace config in `public/config.js` if needed.

### Deploy
- CLI:
  ```bash
  ./scripts/deploy_firebase.sh videos-37e8f
  ```
- GitHub Actions:
  - Add secret **FIREBASE_SERVICE_ACCOUNT_VIDEOS_37E8F** = the JSON of your Firebase Service Account (Editor + Firebase Admin).
  - Push to `main`. Workflow `.github/workflows/firebase-hosting-merge.yml` will deploy.

### Security
- Only **admin** can write `admin/*` docs. We inject `innerHTML` from `admin/ads` — **admin-only rule required** (enforced in `firestore.rules`).
- Only owner or admin can modify a video.
- Comments: create if signed-in, delete by author or admin.
- Storage: Users can write only to `videos/{uid}/**`.

### Video Player Notes
- MP4/upload uses a custom overlay and controls.
- YouTube links render via simple iframe with click-to-start. For full custom control, integrate **YouTube Iframe API** (see comments in `public/js/player.js`).

### Integrating Google IMA (video ads)
- Where we simulate 3s overlay in `openVideo()`, replace with IMA SDK init:
  1. Load IMA SDK JS.
  2. Create `google.ima.AdsLoader`, request ads using `window.__VAST_TAG__`.
  3. On `AdsManagerLoaded`, start ads, then play content.

### Tests
- `npm test` runs Jest:
  - `tests/test_server.js` → checks `GET /api/health`

### Local rule testing
```bash
firebase emulators:start --only firestore,storage,hosting
# Try creating documents and verify allow/deny in emulator UI.
```

### Troubleshooting
- **auth/unauthorized-domain** → Add your domain to Firebase Auth → Authorized domains.
- **permission-denied** → Check `firestore.rules` published and your user role.
- **popup blocked** → We use **signInWithRedirect** for Google by default.
- **Storage URL access** → For private buckets use `/api/sign?path=...` to get a signed URL.
