// server/index.js
import express from 'express';
import cors from 'cors';
import fetch from 'node-fetch';
import * as admin from 'firebase-admin';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

// Initialize Firebase Admin if SA provided
let adminInited = false;
try {
  if (!admin.apps.length) {
    const serviceAccount = process.env.GOOGLE_APPLICATION_CREDENTIALS_JSON
      ? JSON.parse(process.env.GOOGLE_APPLICATION_CREDENTIALS_JSON)
      : null;
    if (serviceAccount) {
      admin.initializeApp({
        credential: admin.credential.cert(serviceAccount),
        storageBucket: process.env.FIREBASE_STORAGE_BUCKET || undefined
      });
      adminInited = true;
    }
  }
} catch (e) {
  console.error('Admin init failed', e);
}

app.get('/api/health', (req,res)=>{
  res.json({ ok: true, time: new Date().toISOString() });
});

// Fetch OG metadata for external links (avoid CORS from client)
app.get('/api/og', async (req,res)=>{
  const { url } = req.query;
  if (!url) return res.status(400).json({ error: 'url required' });
  try {
    const r = await fetch(url);
    const html = await r.text();
    const title = /<title>(.*?)<\/title>/i.exec(html)?.[1] || '';
    const og = {};
    (html.match(/<meta[^>]+>/gi) || []).forEach(m=>{
      const name = /property=["']og:([^"']+)/i.exec(m)?.[1];
      const content = /content=["']([^"']+)/i.exec(m)?.[1];
      if (name && content) og[name]=content;
    });
    res.json({ title, og });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Signed URL for private files in Storage (optional)
app.get('/api/sign', async (req,res)=>{
  if (!adminInited) return res.status(500).json({ error: 'Admin not initialized' });
  const path = req.query.path;
  if (!path) return res.status(400).json({ error: 'path required' });
  try {
    const bucket = admin.storage().bucket();
    const file = bucket.file(path);
    const [url] = await file.getSignedUrl({ action: 'read', expires: Date.now()+ 60*60*1000, version: 'v4' });
    res.json({ url });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

const PORT = process.env.PORT || 8080;
app.listen(PORT, ()=>console.log('Server listening on', PORT));
