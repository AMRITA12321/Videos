#!/usr/bin/env bash
set -euo pipefail
PROJECT_ID=${1:-videos-37e8f}
echo "Using project: $PROJECT_ID"
firebase use $PROJECT_ID
firebase deploy --only hosting,firestore:rules,storage
