// public/config.js
// Replace with your Firebase web config. Provided by Amrita:
export const firebaseConfig = {
  apiKey: "AIzaSyBIwk_zUPiVrMtPGSh7AVTjO_zgUCt2dp8",
  authDomain: "videos-37e8f.firebaseapp.com",
  databaseURL: "https://videos-37e8f-default-rtdb.firebaseio.com",
  projectId: "videos-37e8f",
  storageBucket: "videos-37e8f.firebasestorage.app",
  messagingSenderId: "518714664903",
  appId: "1:518714664903:web:691c37e0e9978607cadbe2",
  measurementId: "G-FDY9ZRJZFD"
};
