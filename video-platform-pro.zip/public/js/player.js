// public/js/player.js
export function renderPlayer(container, videoDoc, opts = {}) {
  const isMp4 = videoDoc.type === 'link' && /\.mp4(\?|$)/i.test(videoDoc.externalLink || '');
  const isYouTube = videoDoc.type === 'link' && /(youtube\.com|youtu\.be)/i.test(videoDoc.externalLink || '');
  const isUpload = videoDoc.type === 'upload';

  container.innerHTML = '';
  const player = document.createElement('div');
  player.className = 'player';
  const overlay = document.createElement('div');
  overlay.className = 'play-overlay';
  overlay.innerHTML = '<div class="big"><div class="triangle"></div></div>';
  player.appendChild(overlay);

  if (isMp4 || isUpload) {
    const video = document.createElement('video');
    video.setAttribute('playsinline', '');
    video.muted = true;
    video.preload = 'metadata';
    video.src = isUpload ? (opts.getDownloadURL ? '' : '') : (videoDoc.externalLink || '');
    video.poster = videoDoc.thumbnailUrl || '';
    video.controls = false;

    const ctrls = document.createElement('div');
    ctrls.className = 'controls';
    ctrls.innerHTML = `
      <button data-act="play" class="btn">Play</button>
      <button data-act="mute" class="btn secondary">Unmute</button>
      <button data-act="fs" class="btn secondary">Fullscreen</button>
    `;

    player.appendChild(video);
    player.appendChild(ctrlls);

    let started = false;
    const showControls = () => player.classList.add('show-controls');
    const hideControls = () => player.classList.remove('show-controls');
    overlay.addEventListener('click', async () => {
      showControls();
      if (!started) {
        if (isUpload && opts.getDownloadURL) {
          try {
            video.src = await opts.getDownloadURL();
          } catch (e) { console.error(e); }
        }
        await video.play().catch(()=>{});
        started = true;
        overlay.style.display = 'none';
      }
    });
    player.addEventListener('mousemove', showControls);
    player.addEventListener('mouseleave', hideControls);
    ctrls.addEventListener('click', async (e)=>{
      const act = e.target.dataset.act;
      if (act === 'play') {
        if (video.paused) { await video.play(); e.target.textContent='Pause'; }
        else { video.pause(); e.target.textContent='Play'; }
      } else if (act === 'mute') {
        video.muted = !video.muted;
        e.target.textContent = video.muted ? 'Unmute' : 'Mute';
      } else if (act === 'fs') {
        if (player.requestFullscreen) player.requestFullscreen();
      }
    });

    // Save watch position
    if (opts.onProgress) {
      video.addEventListener('timeupdate', () => {
        opts.onProgress(video.currentTime, video.duration);
      });
    }

    container.appendChild(player);
  } else if (isYouTube) {
    // Simple click-to-start for YouTube. For full controls use YouTube Iframe API (documented in README).
    const iframe = document.createElement('iframe');
    iframe.width = '100%';
    iframe.height = videoDoc.isShort ? '420' : '300';
    iframe.src = '';
    iframe.allow = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share';
    iframe.allowFullscreen = true;

    overlay.addEventListener('click', () => {
      const id = extractYouTubeId(videoDoc.externalLink);
      iframe.src = `https://www.youtube.com/embed/${id}?autoplay=1&playsinline=1&rel=0`;
      overlay.style.display = 'none';
      player.classList.add('show-controls');
    });

    const thumb = document.createElement('div');
    thumb.className = 'thumb';
    thumb.innerHTML = videoDoc.thumbnailUrl ? `<img src="${videoDoc.thumbnailUrl}" alt="thumb">` : '<span style="color:#7f8ea3">YouTube</span>';
    player.appendChild(thumb);
    player.appendChild(overlay);
    player.appendChild(iframe);
    container.appendChild(player);
  } else {
    const a = document.createElement('a');
    a.href = videoDoc.externalLink || '#';
    a.target = '_blank';
    a.textContent = 'Open external video';
    player.appendChild(a);
    container.appendChild(player);
  }
}

export function extractYouTubeId(url='') {
  const m = url.match(/(?:v=|\.be\/|embed\/)([A-Za-z0-9_-]{6,})/);
  return m ? m[1] : url;
}
