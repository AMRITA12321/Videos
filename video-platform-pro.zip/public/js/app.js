// public/js/app.js
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-app.js";
import { getAuth, GoogleAuthProvider, signInWithRedirect, getRedirectResult, onAuthStateChanged, signOut, signInWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";
import { getFirestore, doc, setDoc, getDoc, updateDoc, addDoc, collection, serverTimestamp, onSnapshot, query, orderBy, where, getDocs, deleteDoc, increment } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-firestore.js";
import { getStorage, ref, uploadBytesResumable, getDownloadURL } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-storage.js";
import { firebaseConfig } from "/config.js";
import { renderPlayer, extractYouTubeId } from "/js/player.js";

// Firebase init
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const storage = getStorage(app);

// Elements
const grid = document.getElementById('video-grid');
const authBadge = document.getElementById('auth-badge');
const uploadsFlag = document.getElementById('uploads-flag');
const btnShareLink = document.getElementById('btn-share-link');
const btnUploadFile = document.getElementById('btn-upload-file');
const btnGoogle = document.getElementById('btn-google');
const btnEmail = document.getElementById('btn-email');
const btnSignout = document.getElementById('btn-signout');

// Admin-only elements (loaded when on admin.html too)
const storageEnabled = document.getElementById('storage-enabled');
const bannedWordsInput = document.getElementById('banned-words');
const btnSaveConfig = document.getElementById('btn-save-config');
const adsEnabled = document.getElementById('ads-enabled');
const vastTagInput = document.getElementById('vast-tag');
const htmlTop = document.getElementById('html-top');
const htmlSidebar = document.getElementById('html-sidebar');
const targetVideoId = document.getElementById('targetVideoId');
const btnSaveAds = document.getElementById('btn-save-ads');
const reportList = document.getElementById('report-list');

// Site-wide ad injection
const topAdSlot = document.getElementById('top-ad');
const sidebarAdSlot = document.getElementById('sidebar-ad');
onSnapshot(doc(db,'admin','ads'), (snap)=>{
  const d = snap.data();
  if (!d) return;
  if (d.enabled && topAdSlot) topAdSlot.innerHTML = d.htmlTop || '';
  if (d.enabled && sidebarAdSlot) sidebarAdSlot.innerHTML = d.htmlSidebar || '';
  window.__VAST_TAG__ = d.vastTag || '';
  window.__TARGET_VIDEO__ = d.targetVideoId || '';
});

// Auth
btnGoogle?.addEventListener('click', async () => {
  const provider = new GoogleAuthProvider();
  // Redirect sign-in (popup-safe)
  await signInWithRedirect(auth, provider);
});
btnEmail?.addEventListener('click', async ()=>{
  const email = prompt('Email:');
  const pass = prompt('Password:');
  if (!email || !pass) return;
  await signInWithEmailAndPassword(auth, email, pass).catch(e=>alert(e.message));
});
btnSignout?.addEventListener('click', ()=>signOut(auth));

getRedirectResult(auth).catch(()=>{});
onAuthStateChanged(auth, async (user)=>{
  if (user) {
    authBadge.textContent = user.email || user.displayName || 'Signed in';
    // Create user doc if missing
    const uref = doc(db,'users', user.uid);
    const u = await getDoc(uref);
    if (!u.exists()) {
      await setDoc(uref, { email: user.email || null, displayName: user.displayName || null, role:'user', createdAt: serverTimestamp() });
    }
  } else {
    authBadge.textContent = 'Signed out';
  }
});

// Read admin config
onSnapshot(doc(db,'admin','config'), (snap)=>{
  const c = snap.data() || { storageUploadsEnabled:false, bannedWords:[] };
  if (uploadsFlag) uploadsFlag.textContent = 'Uploads: ' + (c.storageUploadsEnabled ? 'enabled' : 'disabled');
  if (storageEnabled) storageEnabled.checked = !!c.storageUploadsEnabled;
  if (bannedWordsInput) bannedWordsInput.value = (c.bannedWords || []).join(',');
});

// Save admin config
btnSaveConfig?.addEventListener('click', async ()=>{
  const user = auth.currentUser;
  if (!user) return alert('Sign in as admin');
  const u = await getDoc(doc(db,'users', user.uid));
  if (u.data()?.role !== 'admin') return alert('Not admin');
  await setDoc(doc(db,'admin','config'), {
    storageUploadsEnabled: !!storageEnabled.checked,
    bannedWords: bannedWordsInput.value.split(',').map(s=>s.trim()).filter(Boolean),
    updatedAt: serverTimestamp()
  }, { merge:true });
  alert('Saved config');
});

// Save ads
btnSaveAds?.addEventListener('click', async ()=>{
  const user = auth.currentUser;
  if (!user) return alert('Sign in as admin');
  const u = await getDoc(doc(db,'users', user.uid));
  if (u.data()?.role !== 'admin') return alert('Not admin');
  await setDoc(doc(db,'admin','ads'), {
    enabled: !!adsEnabled.checked,
    htmlTop: htmlTop.value,
    htmlSidebar: htmlSidebar.value,
    vastTag: vastTagInput.value,
    targetVideoId: targetVideoId.value || null,
    updatedAt: serverTimestamp()
  }, { merge:true });
  alert('Saved ads doc');
});

// Share link
document.getElementById('btn-share-link')?.addEventListener('click', async ()=>{
  const user = auth.currentUser;
  if (!user) return alert('Sign in first');
  const title = document.getElementById('title').value.trim();
  const description = document.getElementById('description').value.trim();
  const externalLink = document.getElementById('externalLink').value.trim();
  const thumbnailUrl = document.getElementById('thumbnailUrl').value.trim();
  const visibility = document.getElementById('visibility').value;
  if (!externalLink) return alert('Provide a link');
  const isShort = /tiktok|shorts|reel|vertical/i.test(externalLink);
  await addDoc(collection(db,'videos'), {
    ownerId: user.uid, title, description, thumbnailUrl: thumbnailUrl || null,
    type: 'link', storagePath: null, externalLink, isShort,
    createdAt: serverTimestamp(), views:0, likes:0, commentsCount:0, visibility
  });
  alert('Saved link');
  document.getElementById('externalLink').value='';
});

// Upload file
document.getElementById('btn-upload-file')?.addEventListener('click', async ()=>{
  const user = auth.currentUser;
  if (!user) return alert('Sign in first');
  const cfg = (await getDoc(doc(db,'admin','config'))).data();
  if (!cfg?.storageUploadsEnabled) return alert('Uploads disabled by admin');
  const f = document.getElementById('fileInput').files[0];
  if (!f) return alert('Choose a file');
  const title = document.getElementById('title').value.trim() || f.name;
  const description = document.getElementById('description').value.trim();
  const visibility = document.getElementById('visibility').value;
  const path = `videos/${user.uid}/${Date.now()}_${f.name}`;
  const task = uploadBytesResumable(ref(storage, path), f);
  task.on('state_changed', ()=>{}, (err)=>alert(err.message), async ()=>{
    const url = await getDownloadURL(task.snapshot.ref);
    await addDoc(collection(db,'videos'), {
      ownerId: user.uid, title, description, thumbnailUrl: null, type:'upload',
      storagePath: path, externalLink: url, isShort:false, createdAt: serverTimestamp(),
      views:0, likes:0, commentsCount:0, visibility
    });
    alert('Uploaded!');
  });
});

// Load lists
async function loadFeed(kind='home'){
  const q = query(collection(db,'videos'), orderBy('createdAt','desc'));
  const qs = await getDocs(q);
  grid.innerHTML = '';
  qs.forEach((docSnap)=>{
    const v = { id: docSnap.id, ...docSnap.data() };
    if (kind==='uploaded' && v.type!=='upload') return;
    const card = document.createElement('div');
    card.className = 'card';
    const thumb = document.createElement('div');
    thumb.className = 'thumb';
    const img = v.thumbnailUrl ? `<img src="${v.thumbnailUrl}">` : `<div style="color:#7f8ea3">No thumbnail</div>`;
    thumb.innerHTML = img + (v.isShort?'<span class="badge" style="position:absolute;top:8px;left:8px">Short</span>':'');
    const meta = document.createElement('div');
    meta.className = 'meta';
    meta.innerHTML = `<strong>${v.title || '(untitled)'}</strong><div style="opacity:.8">${v.description || ''}</div>
      <div style="display:flex;gap:8px;margin-top:8px">
        <button class="btn secondary" data-open="${v.id}">Open</button>
        <button class="btn secondary" data-like="${v.id}">👍 ${v.likes||0}</button>
        <button class="btn secondary" data-share="${location.origin}#v=${v.id}">Share</button>
      </div>`;
    card.appendChild(thumb); card.appendChild(meta);
    grid.appendChild(card);
  });
}

window.addEventListener('hashchange', ()=>route());
function route(){
  const h = location.hash;
  if (h.startsWith('#/uploaded')) loadFeed('uploaded');
  else if (h.startsWith('#/trending')) loadFeed('trending');
  else loadFeed('home');
  document.querySelectorAll('nav a').forEach(a=>a.classList.remove('active'));
  const map = { '#/':'nav-home', '#/trending':'nav-trending','#/new':'nav-new','#/hot':'nav-hot','#/uploaded':'nav-uploaded','#/history':'nav-history','#/profile':'nav-profile' };
  const id = map[h] || 'nav-home';
  document.getElementById(id)?.classList.add('active');
}
route();

// Open modal page navigation
grid?.addEventListener('click', async (e)=>{
  const vid = e.target.dataset.open;
  const likeId = e.target.dataset.like;
  const share = e.target.dataset.share;
  if (vid) openVideo(vid);
  if (likeId) await updateDoc(doc(db,'videos', likeId), { likes: increment(1) });
  if (share) {
    await navigator.clipboard.writeText(share);
    alert('Link copied!');
  }
});

async function openVideo(id){
  const d = await getDoc(doc(db,'videos', id));
  if (!d.exists()) return alert('Missing');
  const v = { id, ...d.data() };
  const wrap = document.createElement('div');
  wrap.className = 'card';
  wrap.style.padding = '16px';
  const playerSlot = document.createElement('div');
  wrap.appendChild(playerSlot);
  const meta = document.createElement('div');
  meta.style.marginTop = '8px';
  meta.innerHTML = `<h3>${v.title||''}</h3><div>${v.description||''}</div>`;
  wrap.appendChild(meta);

  grid.innerHTML='';
  grid.appendChild(wrap);

  // Simulated video ad hook
  if (window.__VAST_TAG__ && (!window.__TARGET_VIDEO__ || window.__TARGET_VIDEO__===id)) {
    const ad = document.createElement('div');
    ad.className = 'badge';
    ad.textContent = 'Ad playing... (simulate 3s)';
    wrap.prepend(ad);
    await new Promise(r=>setTimeout(r, 3000));
    ad.remove();
    // TODO: Integrate IMA SDK here (see README)
  }

  // Watch position save
  const user = auth.currentUser;
  const onProgress = async (pos, dur)=>{
    if (!user) return;
    await setDoc(doc(db,'users', user.uid), { watchHistory: { [id]: { pos, dur, at: Date.now() } } }, { merge:true });
  };

  // For uploads, get signed URL via helper API (if using private files). Here we use public URL.
  const getDl = async ()=> v.externalLink;

  renderPlayer(playerSlot, v, { onProgress, getDownloadURL: getDl });

  // increment views
  await updateDoc(doc(db,'videos', id), { views: increment(1) });
}

// Admin page wire-up
if (location.pathname.endsWith('/admin.html')) {
  onAuthStateChanged(auth, async (user)=>{
    if (!user) return;
    const u = (await getDoc(doc(db,'users', user.uid))).data();
    if (u?.role !== 'admin') {
      alert('Not admin'); location.href='/index.html'; return;
    }
    // Load current ads
    const a = await getDoc(doc(db,'admin','ads'));
    if (a.exists()) {
      const d = a.data();
      if (adsEnabled) adsEnabled.checked = !!d.enabled;
      if (vastTagInput) vastTagInput.value = d.vastTag || '';
      if (htmlTop) htmlTop.value = d.htmlTop || '';
      if (htmlSidebar) htmlSidebar.value = d.htmlSidebar || '';
      if (targetVideoId) targetVideoId.value = d.targetVideoId || '';
    }
    // Load reports
    onSnapshot(collection(db,'reports'), (snap)=>{
      reportList.innerHTML = '';
      snap.forEach(r=>{
        const d = r.data();
        const div = document.createElement('div');
        div.className='badge';
        div.textContent = `${r.id}: ${d.reason || ''} by ${d.authorId || ''}`;
        reportList.appendChild(div);
      });
    });

    document.getElementById('btn-save-video')?.addEventListener('click', async ()=>{
      const id = document.getElementById('v-id').value.trim();
      const payload = {
        ownerId: user.uid,
        title: document.getElementById('v-title').value,
        description: document.getElementById('v-desc').value,
        thumbnailUrl: document.getElementById('v-thumb').value,
        externalLink: document.getElementById('v-link').value,
        type: document.getElementById('v-link').value ? 'link':'upload',
        storagePath: null,
        isShort: document.getElementById('v-short').checked,
        visibility: document.getElementById('v-visibility').value,
        updatedAt: serverTimestamp()
      };
      if (id) {
        await updateDoc(doc(db,'videos', id), payload);
        alert('Updated');
      } else {
        await addDoc(collection(db,'videos'), { ...payload, createdAt: serverTimestamp(), views:0, likes:0, commentsCount:0 });
        alert('Created');
      }
    });

    document.getElementById('btn-delete-video')?.addEventListener('click', async ()=>{
      const id = document.getElementById('v-id').value.trim();
      if (!id) return alert('Provide id');
      await deleteDoc(doc(db,'videos', id));
      alert('Deleted');
    });
  });
}
