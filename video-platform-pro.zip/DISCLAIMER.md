# Disclaimer / দায়সারা কথা (Short)

**English:** Content is user-generated. We do not claim ownership. External embeds remain under their respective platform policies.  
**Bangla:** কনটেন্ট ব্যবহারকারীদের দ্বারা তৈরি। এর মালিকানা আমাদের নয়। বাহ্যিক এম্বেড তাদের নিজস্ব প্ল্যাটফর্ম নীতিমালার অধীনে থাকবে।
